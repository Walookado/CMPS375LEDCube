To Run:
	- Double Click the included .exe

Current Release Stuff:
	- Only will run on Windows
	- To run a simulation on patterns simply copy and paste them into the pattern.txt file
	
Simulation Text Format Warning:
	- If there are comments on the same line as a pattern, that pattern will be ignored
	- Simulation will either crash or fail to run if there are spaces on any line before a pattern or comment
		- So to ensure there are no unwanted white space padding to the left of patterns and comments do a simple
		  find and replace where you find (    B) and replace with (B) or (    /) with (/).
		  Basically just highlight all the empty white space and the first symbol of a line and replace it with just that symbol
		  and there will be no more bad white space.